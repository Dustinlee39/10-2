// Main JavaScript file for interactivity
document.addEventListener('DOMContentLoaded', function() {
    console.log('Document is ready.');
});