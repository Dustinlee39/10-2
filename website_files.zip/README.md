# My Website

## Overview
This project is a basic website structure including HTML, CSS, and JavaScript files. It contains sample pages for the home, about, contact, and blog sections.

## Files
- **index.html**: The main HTML file.
- **styles.css**: CSS file for styling.
- **main.js**: JavaScript file for interactivity.
- **about.html**: Sample about page.
- **contact.html**: Sample contact page.
- **blog.html**: Sample blog page.
- **sitemap.xml**: Example sitemap.
- **robots.txt**: Guide for search engine crawlers.
- **.htaccess**: Configuration file for security and redirects.
- **README.md**: Documentation file summarizing the project.